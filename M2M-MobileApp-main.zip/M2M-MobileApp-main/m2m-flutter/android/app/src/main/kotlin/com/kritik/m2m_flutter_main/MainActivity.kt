package com.kritik.m2m_flutter_main

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
