import 'package:m2m_flutter_main/model/user.dart';

class UserPreferences {
  static const myUser = User(
    imagePath:
        'https://media.istockphoto.com/photos/cool-cat-with-shades-picture-id1249884596?k=20&m=1249884596&s=612x612&w=0&h=16nnd8JAJW2MdEghUJnaAiZfPezWoVUTAW9bwOE3Z7E=',
    name: 'irem pekkıyak',
    city: 'Ankara',
    major: 'Software Developer',
    about:
        'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas id augue et libero tempus vehicula ac vitae lectus. Integer eu velit vestibulum, aliquet libero at, tristique sem.',
  );
}
